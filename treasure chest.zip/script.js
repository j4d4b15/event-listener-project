document.addEventListener("DOMContentLoaded", (event) => {
// Add JavaScript code for your web site here and call it from index.html.
let optionOne = document.querySelector(".option-one");
      let optionOneScreen = document.querySelector(".option-one-screen");
    
      let optionTwo = document.querySelector(".option-two");
      let optionTwoScreen = document.querySelector(".option-two-screen");
    
      let beginning = document.querySelector(".story_opening");
      let box = document.querySelector(".box");
    
      optionOne.addEventListener("click", function(){
       optionOneScreen.style.display="block";
       box.style.display="none";
       beginning.style.display="none";

       
       
      });
    // Add to the code below to show & hide elements when the 2nd button is clicked. Look above for samples or how to.
      optionTwo.addEventListener("click", function(){
        
      });
    
    });